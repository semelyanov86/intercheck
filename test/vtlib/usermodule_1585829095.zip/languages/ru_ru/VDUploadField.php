<?php

$languageStrings = array(
    'VDUploadField' => 'Upload Field',
    'LBL_MODULE' => 'Module',
    'LBL_NAME' => 'Name',
    'LBL_LABEL' => 'Label',  
    'LBL_BLOCK' => 'Block',
    'LBL_FIELD_TYPE' => 'Field type',
    'LBL_ASSIGN_TO_FIELD' => 'Assigned To',    
    'LBL_UPLOAD_FIELD' => 'Upload field',    
        'LBL_INFO_BLOCK'=>'Info',
        'LBL_INFO_BLOCK_ON_SETTING_PAGE'=>'No configuration is needed.',
        'LBL_INFO_BLOCK_ON_SETTING_PAGE_V6'=>'No configuration is needed.',
);
