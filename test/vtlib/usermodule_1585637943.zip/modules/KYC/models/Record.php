<?php

class KYC_Record_Model extends Vtiger_Record_Model
{

}