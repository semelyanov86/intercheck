<?php

class Commissions_Record_Model extends Vtiger_Record_Model
{

   
}