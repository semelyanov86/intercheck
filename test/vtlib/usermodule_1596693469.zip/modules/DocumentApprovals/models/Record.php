<?php

class DocumentApprovals_Record_Model extends Vtiger_Record_Model
{

}